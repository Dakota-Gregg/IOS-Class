
import Foundation
import UIKit

func recursivePairing(ar: [Int], matches: Int) -> Int {
    var mates = matches
    if ar.count > 0 {
        var tempar = ar
        let sock = tempar.remove(at: 0)
        for (i, tempsocks) in tempar.enumerated() {
            if tempsocks == sock {
                tempar.remove(at: i)
                mates += 1
                break
            }
        }
        return recursivePairing(ar: tempar, matches: mates)
    }
    return mates
}
var matches = recursivePairing(ar: [1,1,3,1,2,1,3,3,3],matches: 0)
print(matches)
