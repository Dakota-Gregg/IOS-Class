import Foundation
func twostrings(ar:[String] ){
    var bool = 0
    var mySet = CharacterSet()
    for i in ar{
        mySet = .init(charactersIn: i)
        for j in ar{
            if(j != i ){
                if j.rangeOfCharacter(from: mySet) != nil{
                    bool = 1
                }
            }
        }
    }
    if(bool == 1)
    {
        print("yes")
    }
    else{
        print("no")
    }
}

twostrings(ar: ["big","small"])
